package com.example.studentmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class StudentDetailsActivity extends AppCompatActivity {

    TextView tv_name,tv_phone,tv_Email,tv_Dob,tv_division,tv_gender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);
        tv_name=findViewById(R.id.tv_name);
        tv_division=findViewById(R.id.tv_division);
        tv_Dob=findViewById(R.id.tv_dob);
        tv_gender=findViewById(R.id.tv_gender);
        tv_Email=findViewById(R.id.tv_Email);
        tv_phone=findViewById(R.id.tv_phone);
        Intent intent = getIntent();
        Student student = (Student) intent.getSerializableExtra("student");

       // Toast.makeText(this, student.getEmail(), Toast.LENGTH_SHORT).show();
        tv_name.setText(student.getName());
        tv_phone.setText(student.getPhone());
        tv_Email.setText(student.getEmail());
        tv_Dob.setText(student.getDob());
        tv_division.setText(student.getDivision());
        tv_gender.setText(student.getGender());


    }
}